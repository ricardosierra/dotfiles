# Ember CLI

**Maintainers:** [BilalBudhani](https://github.com/BilalBudhani), [eubenesa](https://github.com/eubenesa), [scottkidder](https://github.com/scottkidder]

Ember CLI (https://www.ember-cli.com/)

### List of Aliases

Alias | Ember-CLI command
----- | -----------------
**es** | *ember serve*
**ea** | *ember addon*
**eb** | *ember build*
**ed** | *ember destroy*
**eg** | *ember generate*
**eh** | *ember help*
**ein** | *ember init*
**ei** | *ember install*
**et** | *ember test*
**ets** | *ember test --serve*
**eu** | *ember update*
**ev** | *ember version*
